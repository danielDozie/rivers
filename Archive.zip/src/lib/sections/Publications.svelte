<script>
	let posts = [
		{
			title: 'Lorem ipsum dolor sit amet consectetur, adipisicing elit. Eaque modi, perspiciatis impedit libero quas facilis quos voluptates dolores? Fuga itaque totam quae voluptas ratione culpa voluptatum nihil aspernatur labore veritatis!',
			via: 'facebook',
            image: '/nature.jpg',
		},
		{
			title: 'Lorem ipsum dolor sit amet consectetur, adipisicing elit. Eaque modi, perspiciatis impedit libero quas facilis quos voluptates dolores? Fuga itaque totam quae voluptas ratione culpa voluptatum nihil aspernatur labore veritatis!',
			via: 'instagram',
            image: '/onion.jpg',
		},
		{
			title: 'Lorem ipsum dolor sit amet consectetur, adipisicing elit. Eaque modi, perspiciatis impedit libero quas facilis quos voluptates dolores? Fuga itaque totam quae voluptas ratione culpa voluptatum nihil aspernatur labore veritatis!',
			via: 'twitter',
            image: '/house.jpg',
		},
		{
			title: 'Lorem ipsum dolor sit amet consectetur, adipisicing elit. Eaque modi, perspiciatis impedit libero quas facilis quos voluptates dolores? Fuga itaque totam quae voluptas ratione culpa voluptatum nihil aspernatur labore veritatis!',
			via: 'youtube',
            image: '/lion.jpg',
		},
		{
			title: 'Lorem ipsum dolor sit amet consectetur, adipisicing elit. Eaque modi, perspiciatis impedit libero quas facilis quos voluptates dolores? Fuga itaque totam quae voluptas ratione culpa voluptatum nihil aspernatur labore veritatis!',
			via: 'tiktok',
            image: '/onion.jpg',
		},
		{
			title: 'Lorem ipsum dolor sit amet consectetur, adipisicing elit. Eaque modi, perspiciatis impedit libero quas facilis quos voluptates dolores? Fuga itaque totam quae voluptas ratione culpa voluptatum nihil aspernatur labore veritatis!',
			via: 'tiktok',
            image: '/house.jpg',
		},
        {
			title: 'Lorem ipsum dolor sit amet consectetur, adipisicing elit. Eaque modi, perspiciatis impedit libero quas facilis quos voluptates dolores? Fuga itaque totam quae voluptas ratione culpa voluptatum nihil aspernatur labore veritatis!',
			via: 'facebook',
            image: '/nature.jpg',
		},
		{
			title: 'Lorem ipsum dolor sit amet consectetur, adipisicing elit. Eaque modi, perspiciatis impedit libero quas facilis quos voluptates dolores? Fuga itaque totam quae voluptas ratione culpa voluptatum nihil aspernatur labore veritatis!',
			via: 'instagram',
            image: '/onion.jpg',
		},
	];
</script>

<div class="w-full h-full flex flex-auto mx-auto justify-apart bg-[#D4DEEB]/60" id="publications">
	<!-- <div class="w-[20px] md:w-[150px] md:inline-block bg-blueDeep">
		<div class="rotate-90 scale-x-flip scale-y-flip sticky top-[50%] mt-[36rem] mb-20">
			<h1 class="font-ibmplex font-bold text-[72px] text-white/70 invisible md:visible">PUBLICATIONS</h1>
		</div>
	</div> -->
	<div class="w-full mx-auto px-4 md:px-16 pb-20 justify-center mt-32">
        
        <div class="">
			<h1 class="font-hammersmith text-[28px] md:text-[45px] mb-8 leading-0">
				Publications <span class="text-blueLight">- News</span> and Updates.
			</h1>
		</div>
        
        <div class="w-full flex flex-wrap mx-auto justify-center gap-4">
            <!-- {#each posts as post}
            <div class="w-full md:w-[320px] h-[220px] relative hvr-float"> 
                <img src={post.image} alt="publication" class="w-full h-full rounded-[10px]"/>
                <div class="w-full h-28 bottom-0 rounded-b-[10px] hover:rounded-b-[10px] bg-blueDeep/70 absolute hover:bg-blueDeep"> 
                    <div class="w-[90%] flex flex-col cursor-pointer">
                        <h1 class="font-ibmplex font-light italic text-[14px] ml-4 mt-4 text-white/80">
                            {post.title.slice(0, 90) + "..."}
                        </h1>
                        <p class="font-ibmplex text-right font-normal italic text-[10px] ml-4 -mt-[2px] text-yellow leading-8">
                            via ~ {post.via}
                        </p>
                    </div>
                </div>
				
            </div>
            {/each} -->
            <!-- <div class="flex justify-center w-full md:w-[320px] h-12 md:h-[220px] relative rounded-[5px] bg-white mt-4 md:mt-0"> 
                <button class="font-bold text-[14px] text-blueLight hover:text-yellow">Load more...</button>
            </div> -->

			<h1 class="text-5xl text-blueDeep animate-pulse my-12">Coming soon!</h1>
        </div>
	</div>
</div>

<script>
        import {readMoreStore} from '$lib/store';
</script>

<div class="mt-16 mb-8 space-y-8">
	<p>
		This was the opening line of the Major General <span class="font-bold">Yakubu Gowon</span> speech to the nation in May 1967
		when twelve States were created out of the (then) four Regions that had existed since the 1950s,
		you’d be encouraged to read the full statement. At the time there was a political crisis that
		was threatening to push the nation into a civil war, an agitation largely emanating from the
		Eastern Region. At the same time, there was a major clamour around the unfortunate, extensive,
		and continued marginalisation experienced by some minorities, a clamour that had somewhat come
		to a very critical point – particularly in again the Eastern Region of the Country.
	</p>
	<p>
		To pre-emptively weaken the growing secessionist movement and strategically attend to the
		clamour of marginalisation, the then Gowon-led Supreme Military Council with Decree No 8 of
		1967, created twelve States out of the four Regions. Rivers State was one of the twelve, with
		Naval Lieutenant Commander Alfred Papapreye Diete-Spiff appointed as Military Administrator; he
		was aged 25 years at the time. Unfortunately, civil war still broke out shortly after and lasted
		about three years. Also known as the Biafran War it was fought between the government of Nigeria
		and the secessionist Republic of Biafra, which surrendered in early 1970 to Nigerian forces
		making famous the Nigerian motto “No-victor, No-vanquished”.
	</p>
	<p>
		With the creation of the State, it is necessary to mention persons that comprised the
		Diete-Spiff led team which steered the affairs of the Rivers State ship from the time of its
		birth for almost a decade on. The State in general, Port Harcourt in particular, have to date
		pretty much lived off the back of the ground work credited to this team of incredible and
		long-sighted men.
	</p>
</div>
<div class={`mb-8 space-y-8 ${$readMoreStore ? 'inline-block' : 'hidden'}`}>
	<p>
		William Pikibo Daniel-Kalio as Secretary to Government and Head of Service; Chief. E. J. A. Orji
		as Commissioner for Economic Development, Trade & Investment; Prof. Lawrence B. Ekpebu (the
		first African graduate of Harvard University) as Commissioner for Finance; Mr. Kenule (Ken) Beeson Saro-Wiwa as Commissioner for Education; Chief Harold J. R. Dappa- Biriye as Commissioner for Agriculture, Fisheries, Natural Resources; Dr. Nabo Bekinbo Graham-Douglas SAN as Attorney General, Commissioner of Justice and Customary Affairs; Mr. N. Nwanodi as Commissioner for Health; Chief S. F. Kombo- Igbeta as Commissioner for Establishments; Mr. O. Ngei for Works, Lands, and Transport; Dr. W. T. Wakama for Local Government & Information; and Dr. Obi Wali as Commissioner for Rehabilitation; to mention just a
		few. This was the era that saw the birth of many State establishments, some of nostalgic memory
		including but not limited to – Pan African Bank – PAB (Founded 1971); PABOD Finance & Investment
		Co. LTD (Founded 1972); Rivers State University of Science & Technology (1972, univ. status
		1980); PABOD Supplies LTD (incl. SUPABOD Stores); University of Port Harcourt (1975); PABOD
		Breweries (Founded 1978); and saw (approximately) a third of the (then) Port Harcourt landmass
		dedicated to the birth of the Trans Amadi Industrial Layout of today. Most of the development in
		the State was largely driven based on the <span class="font-bold">Rivers State Programmes of the Third National
			Development Plan</span>, 1975-1980, formally launched at City Hall, Port Harcourt, Thursday, 1st May,
		1975, by the State Military Administrator.
	</p>
	<p>
		Detailed history of these events, times, and peoples, are better served by other platforms.
		Named after the many rivers that bordered its territory, Rivers State, the ‘Treasure Base of the
		Nation’, was created with a total landmass of approximately 21,850sqkm, a total coast line of
		about 305km, and having its capital at the city of Port Harcourt. In October 1996, a new State
		(Bayelsa) was carved out of the western side of the existing Rivers State by the General <span class="font-bold">Sanni
			Abacha</span> led Federal Military Government; resulting in a residual landmass of about 11,077sqkm and
		a coastline of approximately 121.55km.
	</p>
	<p>
		A population of about 3.8m persons inhabited the new State as at 1997, with circa 522,000 or
		13.7% located in the capital. This grew to about 5.2m inhabitants as at the last (known)
		National census exercise which was conducted in 2006, with about 26.6% of this figure residing
		in the capital Port Harcourt. Currently (as at c2021), an estimated 7.3m inhabitants have been
		recorded within the State by United Nations sources, with approximately 43.8% resident in the
		capital. A total of about sixteen administrations have managed the affairs of the State since
		its creation with the pioneer being the Alfred Diete-Spiff led period of 1967-1975. About 62.5%
		of these total administrative cycles have been led by military officers, while 37.5% of the
		total of sixteen administrations have functioned since the creation of the current Rivers State
		in 1996, leading up to the current Administration which is due to terminate in May 2023 and
		usher in the next.
	</p>

	<p>
		Both locally and internationally Rivers State is widely known for its Oil and Gas sector,
		representing the core of its local economy and indeed the National revenue base. Totally
		eclipsing other sectors such as fishing, palm-oil production, and casava farming, the
		petrochemical economy accounted for over 77.27% of the State’s IGR between 2007 and 2020. The
		Rivers State economy is currently worth USD21bn pitching it as the second largest economy in the
		country (2020 NIPC Book of States reports), and largest amongst the six States that make up the
		Niger Delta Region. It is necessary to note that these statistics are all pre-COVID.
	</p>
	<p>
		The State operates 23 Local Government Areas (LGAs), Port Harcourt inclusive, most of which are
		generally identified by their Up-land or Riverine nature. AKULGA represents the largest in
		landmass at about 13%, with OGU-BOLO LGA at the other end at 0.8%, just shy of the capital Port
		Harcourt which is only 0.98% of total State landmass. OBIO-AKPOR LGA at 2.3% landmass, which
		shares boundary with the capital, houses virtually the entirety of the State’s economy –
		including industries, tertiary institutions, medical facilities, transportation hubs, and
		military installations amongst others. This said however the last decade has also seen a degree
		of fiscal and infrastructural expansion particularly into IKWERRE LGA (5.91% landmass) in the
		precinct around the International Airport, Omagwa namely Greater Port Harcourt and the New RSUST
		Campus amongst many others.
	</p>
	<p>
		In all of this the current State has been and remains without a <span class="font-bold">Development Plan</span>. 
	</p>
	<p>Various
		attempts have been recorded in the vein of securing a development blueprint for the State – if
		not in whole, at least in part. Notable instances include efforts by the <span class="font-bold">Rivers State
			Sustainable Development Agency</span> (RSSDA), established by the Rivers State Government in 2007, with
		a scope that was largely centred on promoting programmes and activities aimed at eradicating
		poverty, developing rural areas, and empowering the youth. Next was the very extensive State
		Development Framework as prepared and compiled by RSEAC, the <span class="font-bold">Rivers State Economic Advisory
		Council</span> 2007-2014, which amongst others, featured plans for a <span class="font-bold">Niger Delta Energy Corridor</span> (NDEC
		2012). The NDEC was an integrated development strategy plan linking through the <span class="font-bold">BRACED States</span> of
		the Niger Delta Region as a core component of the wider recommendations by RSEAC; none of which
      class?: string | undefined | null;
		are yet to experience or receive due consideration to date. Yet another instance was the <span class="font-bold">Rivers
		State Golden Jubilee Committee Report</span> of November 2018 which recommended the establishment of a
		Technical Group to develop a working document for State growth. A recommendation the current
		State Governor readily accepted with a projected 50-year framework target.
	</p>
	<p>
		There is currently still no Development Plan for the State. Development, real and sustainable
		development, is ALWAYS ONLY dependent on the existence of a plan, a well-considered plan. It is
		time to admit and agree we need a plan, else we risk a loss of economic identity, thus becoming
		just a name on a map – with the attendant social implications, human development index
		implications, the list will be endless.
	</p>
	<p>
		Dubai, by plan, has transformed itself from an oil economy to a thriving ‘post-oil’ economy of
		world acclaim, spanning business, hospitality, and tourism industries amongst others. Lagos, by
		plan, has evolved from (its fortunate time as) Nation’s Capital, to the
		financial-commercial-business hub of the Nation, also of world acclaim. Rivers State is yet to
		transition, Rivers State is yet to set a Plan.
	</p>
	<p>
		The <span class="font-bold text-blueLighter">SustainableRIVERS</span> initiative is a platform that seeks to understand the past, particularly
		as it lays foundation for what has evolved into the present, and review the present against a
		series of developmental barometers, to articulate an informed outlook into the future in
		economic, social, development, and political terms amongst others. This agenda-setting
		non-partisan vehicle is designed to steer narrative towards people orientated inclusive growth,
		climate considerate fiscal interventions, investor focused sustainable development, and economy
		strengthening polity maturation. Rivers State founded in 1967, reshaped in 1996, has effectively
		existed for well over fifty years and as such by the turn of the current administrative cycle in
		2023 deserves necessary opportunity to set itself on a long-term path of progressive statehood.
	</p>
	<p>Please join the conversation.</p>
</div>
